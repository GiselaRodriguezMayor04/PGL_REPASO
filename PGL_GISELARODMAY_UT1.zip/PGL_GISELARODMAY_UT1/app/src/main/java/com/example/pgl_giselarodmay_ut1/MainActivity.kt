package com.example.pgl_giselarodmay_ut1

import android.content.ContentValues
import android.os.Bundle
import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.Spinner
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class MainActivity : AppCompatActivity() {

    private lateinit var etnombremain: EditText
    private lateinit var etartistamain: EditText
    private lateinit var etnvisualmain: EditText
    private lateinit var etgeneromain: EditText
    private lateinit var etdiscomain: EditText

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)

        //EditText del xml del Main
        etnombremain = findViewById<EditText>(R.id.etnombremain)
        etartistamain = findViewById<EditText>(R.id.etartistamain)
        etnvisualmain = findViewById<EditText>(R.id.etnvisualmain)
        etgeneromain = findViewById<EditText>(R.id.etgeneromain)
        etdiscomain = findViewById<EditText>(R.id.etdiscomain)

        //Botones del xml del main
        val btinsertarmain = findViewById<Button>(R.id.btinsertarmain)
        //val btmodmain = findViewById<Button>(R.id.btmodmain)
        val bteliminarmain = findViewById<Button>(R.id.bteliminarmain)
        val btbuscarmain = findViewById<Button>(R.id.btbuscarmain)
        val bttodosmain = findViewById<Button>(R.id.bttodosmain)

        //Spinner del xml del main
        val spspinnermain = findViewById<Spinner>(R.id.spspinnermain)

        //Funcionalidades del botón insertar
        btinsertarmain.setOnClickListener {
            val artist = Conexion(this@MainActivity, "CancionesDB", null, 1)
            val bd = artist.writableDatabase
            val tabla = ContentValues()
            tabla.put("nombre", etnombremain.text.toString())
            tabla.put("artista", etartistamain.text.toString())
            tabla.put("visualizaciones", etnvisualmain.text.toString().toInt())
            tabla.put("genero", etgeneromain.text.toString())
            tabla.put("discografica", etdiscomain.text.toString())
            bd.insert("Canciones", null, tabla)
            bd.close()
            muestraMensaje("Registro insertado.")
        }

        //Funcionalidades del botón buscar
        btbuscarmain.setOnClickListener {
            val artist = Conexion(this@MainActivity, "CancionesDB", null, 1)
            val bd = artist.writableDatabase


            val tab = bd.rawQuery(
                "SELECT artista, visualizaciones, genero, discografica FROM Canciones WHERE nombre = '${etnombremain.text}'",
                null
            )

            if (tab.moveToFirst()) {
                etartistamain.setText(tab.getString(0))
                etnvisualmain.setText(tab.getString(1))
                etgeneromain.setText(tab.getString(2))
                etdiscomain.setText(tab.getString(3))
            } else {
                muestraMensaje("El nombre no se encuentra en la BD")
            }
            bd.close()
        }

        bteliminarmain.setOnClickListener{
            if(!etnombremain.text.toString().isEmpty()){
                val artist = Conexion(this@MainActivity, "CancionesDB", null, 1)
                val bd = artist.writableDatabase
                val reg=bd.delete("Canciones", "nombre='${etnombremain.text.toString()}'", null)
                if (reg==1) {
                    muestraMensaje("Registro eliminado correctamente")
                } else {
                    muestraMensaje("No se ha podido eliminar el registro porque no existe la BD")
                }
                bd.close()
                limpiaCampos()
            } else {
                muestraMensaje("El campo nombre no puede estar vacío")
            }
        }

        bttodosmain.setOnClickListener {
            val artista = Conexion (contexto = this@MainActivity, nombre = "CancionesDB", factory = null, version = 1)
            val bd = artista.writableDatabase
            val listanombres = ArrayList<String>()
            val regis = bd.rawQuery("SELECT nombre FROM Canciones",null)
            while (regis.moveToNext()) {
                listanombres.add(regis.getString(0))
            }
            val adaptador = ArrayAdapter(this, androidx.appcompat.R.layout.support_simple_spinner_dropdown_item, listanombres)
            spspinnermain.adapter = adaptador
            bd.close()
        }

        spspinnermain.onItemSelectedListener = object: AdapterView.OnItemSelectedListener {
            override fun onItemSelected(
                parent: AdapterView<*>?,
                view: View?,
                position: Int,
                id: Long
            ) {
                muestraMensaje("Has seleccionado ${parent!!.getItemAtPosition(position)}")
            }
            override fun onNothingSelected(parent: AdapterView<*>?) {
                TODO(reason = "Not yet implemented")
            }
        }

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }
    }

    //MuestraMensaje para que avise de cualquier fallo
    private fun muestraMensaje(s: String) {
        Toast.makeText(this, s , Toast.LENGTH_LONG).show()
    }

    //limpiaCampos para que se quede limpio todo al insertar otros datos
    private fun limpiaCampos (){
        etnombremain.text.clear()
        etartistamain.text.clear()
        etnvisualmain.text.clear()
        etgeneromain.text.clear()
        etdiscomain.text.clear()
    }
}


