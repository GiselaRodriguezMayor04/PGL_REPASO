package com.example.pgl_giselarodmay_ut1

import android.annotation.SuppressLint
import android.content.ContentValues
import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.Spinner
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class Mod : AppCompatActivity() {

    //Hay que declarar las variables fuera del método onCreate porque si no, el método limpiacampos no puede pillar las variables
    private lateinit var etnombremod: EditText
    private lateinit var etartistamod: EditText
    private lateinit var etnvisualmod: EditText
    private lateinit var etgeneromod: EditText
    private lateinit var etdiscomod: EditText

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_mod)

        val etnombremod = findViewById<EditText>(R.id.etnombremod)
        val etartistamod = findViewById<EditText>(R.id.etartistamod)
        val etnvisualmod = findViewById<EditText>(R.id.etnvisualmod)
        val etgeneromod = findViewById<EditText>(R.id.etgeneromod)
        val etdiscomod = findViewById<EditText>(R.id.etdiscomod)
        val btmod = findViewById<Button>(R.id.btmod)
        val btvolvermod = findViewById<Button>(R.id.btvolvermod)

        //Funcionalidad del botón modificar
        btmod.setOnClickListener {
            if (!etnombremod.text.toString().isEmpty()) {
                val artist = Conexion(this@Mod, "CancionesDB", null, 1)
                val bd = artist.writableDatabase
                val tablas = ContentValues()
                tablas.put("artista", etartistamod.text.toString())
                tablas.put("visualizaciones", etnvisualmod.text.toString().toInt())
                tablas.put("genero", etgeneromod.text.toString())
                tablas.put("discografica", etdiscomod.text.toString())

                val reg = bd.update(
                    "Canciones", tablas, "nombre='${etnombremod.text.toString()}'", null
                )

                if (reg == 1) {
                    muestraMensaje("Registro actualizado correctamente")
                } else {
                    muestraMensaje("No se ha podido modificar el registro porque no existe la BD")
                }
                bd.close()
                limpiaCampos()
            } else {
                muestraMensaje("El campo nombre no puede estar vacío")
            }
        }

        btvolvermod.setOnClickListener {
            val volver = Intent(this@Mod, MainActivity::class.java)
            startActivity(volver)
        }
    }

    //MuestraMensaje para que avise de cualquier fallo
    private fun muestraMensaje(s: String) {
        Toast.makeText(this, s, Toast.LENGTH_LONG).show()
    }

    //limpiaCampos para que se quede limpio todo al insertar otros datos
    private fun limpiaCampos() {
        etnombremod.text.clear()
        etartistamod.text.clear()
        etnvisualmod.text.clear()
        etgeneromod.text.clear()
        etdiscomod.text.clear()
    }
}