package com.example.repaso_ut1_pgl

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val TVTitulo = findViewById<TextView>(R.id.TVTitulo)
        val ETUsuario = findViewById<EditText>(R.id.ETUsuario)
        val ETPassword = findViewById<EditText>(R.id.ETPassword)
        val BTEntrar = findViewById<Button>(R.id.BTEntrar)

        BTEntrar.setOnClickListener {
            val usuario = ETUsuario.text.toString()
            val password = ETPassword.text.toString()

            if (usuario == "Admin" && password == "1906Red") {
                val intento1 = Intent(this@MainActivity, Saludo::class.java)
                intento1.putExtra("usuario", usuario)
                startActivity(intento1)
            } else {
                Toast.makeText(this, "Usuario o contraseña incorrectos", Toast.LENGTH_SHORT).show()
            }
        }
    }
}
