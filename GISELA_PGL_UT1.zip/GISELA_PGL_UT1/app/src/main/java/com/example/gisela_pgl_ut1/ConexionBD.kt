package com.example.gisela_pgl_ut1

import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

class ConexionBD (contexto: Context, nombre: String, factory: SQLiteDatabase.CursorFactory?, version: Int): SQLiteOpenHelper(contexto,nombre,factory,version){
    override fun onCreate(db: SQLiteDatabase?) {
        db!!.execSQL("CREATE TABLE Radios(codigo integer primary key, nombre text, tipo text, numoyentes integer, frecuencia double, numpremios integer)")
    }

    override fun onUpgrade(db: SQLiteDatabase?, oldVersion: Int, newVersion: Int) {
        TODO("Not yet implemented")
    }
}