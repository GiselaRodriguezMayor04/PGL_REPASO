package com.example.gisela_pgl_ut1

import android.annotation.SuppressLint
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class Buscar : AppCompatActivity() {
    private lateinit var ETCodigo: EditText
    private lateinit var TVNombre: TextView
    private lateinit var TVTipo: TextView
    private lateinit var TVOyentes: TextView
    private lateinit var TVFrecuencia: TextView
    private lateinit var TVPremios: TextView

    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_buscar)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        ETCodigo = findViewById(R.id.ETCodigoBuscar)
        TVNombre = findViewById(R.id.TVNombreBuscar)
        TVTipo = findViewById(R.id.TVTipoBuscar)
        TVOyentes = findViewById(R.id.TVNumOyentesBuscar)
        TVFrecuencia = findViewById(R.id.TVFrecuenciaBuscar)
        TVPremios = findViewById(R.id.TVNumeroPremiosBuscar)

        val BTConfirmar = findViewById<Button>(R.id.BTConfirmarBuscar)
        val BTVolver = findViewById<Button>(R.id.BTVolverBuscar)

        BTConfirmar.setOnClickListener {
            TVNombre.setText("")
            TVTipo.setText("")
            TVOyentes.setText("")
            TVFrecuencia.setText("")
            TVPremios.setText("")

            val radios = ConexionBD(this@Buscar, "BDGisela", null, 1)
            val bd = radios.writableDatabase

            val regis = bd.rawQuery("SELECT nombre, tipo, numoyentes, frecuencia, numpremios FROM Radios WHERE codigo = ${ETCodigo.text.toString()}",null)
            if(regis.moveToFirst()) {
                TVNombre.setText(regis.getString(0))
                TVTipo.setText(regis.getString(1))
                TVOyentes.setText(regis.getInt(2).toString())
                TVFrecuencia.setText(regis.getDouble(3).toString())
                TVPremios.setText(regis.getInt(4).toString())
            }else {
                muestraMensaje("El codigo del autor no se encuentra en la base de datos")
            }
            bd.close()

            limpiarCampos()
        }

        BTVolver.setOnClickListener {
            finish()
        }
    }

    private fun limpiarCampos() {
        ETCodigo.text.clear()
    }

    private fun muestraMensaje(s: String) {
        Toast.makeText(this,s, Toast.LENGTH_LONG).show()
    }
}