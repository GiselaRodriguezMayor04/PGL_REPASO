package com.example.gisela_pgl_ut1

import android.annotation.SuppressLint
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class Eliminar : AppCompatActivity() {
    private lateinit var ETCodigo: EditText
    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_eliminar)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        ETCodigo = findViewById(R.id.ETCodigoEliminar)

        val BTConfirmar = findViewById<Button>(R.id.BTConfirmarEliminar)
        val BTVolver = findViewById<Button>(R.id.BTVolverEliminar)

        BTConfirmar.setOnClickListener {
            if(!ETCodigo.text.toString().isEmpty()) {
                val radio = ConexionBD(this@Eliminar, "BDGISELA", null, 1)
                val bd = radio.writableDatabase

                val reg = bd.delete("Radios","codigo=${ETCodigo.text.toString().toInt()}",null)
                if(reg == 1) {
                    muestraMensaje("Registro Eliminado")
                }else {
                    muestraMensaje("No se ha podido eliminar ese registro porque no existe en la base de datos ")
                }
                bd.close()
                limpiarCampos()
            }else {
                muestraMensaje("El campo codigo no puede estar vacio")
            }
        }

        BTVolver.setOnClickListener {
            finish()
        }
    }

    private fun limpiarCampos() {
        ETCodigo.text.clear()
    }

    private fun muestraMensaje(s: String) {
        Toast.makeText(this,s, Toast.LENGTH_LONG).show()
    }
}