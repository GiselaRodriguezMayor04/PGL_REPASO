package com.example.gisela_pgl_ut1

import android.annotation.SuppressLint
import android.content.ContentValues
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class Insert : AppCompatActivity() {
    private lateinit var ETCodigo: EditText
    private lateinit var ETNombre: EditText
    private lateinit var ETTipo: EditText
    private lateinit var ETOyentes: EditText
    private lateinit var ETFrecuencia: EditText
    private lateinit var ETPremios: EditText

    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_insert)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        ETCodigo = findViewById(R.id.ETCodigoInsert)
        ETNombre = findViewById(R.id.ETNombreInsert)
        ETTipo = findViewById(R.id.ETTipoInsert)
        ETOyentes = findViewById(R.id.ETNumOyentesInsert)
        ETFrecuencia = findViewById(R.id.ETFrecuenciaInsert)
        ETPremios = findViewById(R.id.ETNumPremiosInsert)

        val BTConfirmar = findViewById<Button>(R.id.btconfirmar)
        val BTVolver = findViewById<Button>(R.id.btvolver)

        BTConfirmar.setOnClickListener {
            val radios = ConexionBD(this@Insert, "BDGISELA", null, 1)
            val bd = radios.writableDatabase

            val registro = ContentValues()
            registro.put("codigo", ETCodigo.text.toString().toInt())
            registro.put("nombre", ETNombre.text.toString())
            registro.put("tipo", ETTipo.text.toString())
            registro.put("numoyentes", ETOyentes.text.toString().toInt())
            registro.put("frecuencia", ETFrecuencia.text.toString().toDouble())
            registro.put("numpremios", ETPremios.text.toString().toInt())
            bd.insert("Radios",null,registro)

            bd.close()
            muestraMensaje("Registro insertado")
            limpiarCampos()
        }

        BTVolver.setOnClickListener {
            finish()
        }
    }

    private fun limpiarCampos() {
        ETCodigo.text.clear()
        ETNombre.text.clear()
        ETTipo.text.clear()
        ETOyentes.text.clear()
        ETFrecuencia.text.clear()
        ETPremios.text.clear()
    }

    private fun muestraMensaje(s: String) {
        Toast.makeText(this,s, Toast.LENGTH_LONG).show()
    }
}