package com.example.gisela_pgl_ut1

import android.annotation.SuppressLint
import android.content.Intent
import android.os.Bundle
import android.widget.Button
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class MainActivity : AppCompatActivity() {

    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        val BTInsertar = findViewById<Button>(R.id.BTInsertar)
        val ActualizarPremios = findViewById<Button>(R.id.BTActualizar)
        val BTEliminar = findViewById<Button>(R.id.BTEliminar)
        val BuscarCodigo = findViewById<Button>(R.id.BTBuscar)


        BTInsertar.setOnClickListener {
            val intento1 = Intent(this@MainActivity, Insert::class.java)
            startActivity(intento1)
        }

        BuscarCodigo.setOnClickListener {
            val intento5 = Intent(this@MainActivity,Buscar::class.java)
            startActivity(intento5)
        }

        ActualizarPremios.setOnClickListener {
            val intento6 = Intent(this@MainActivity,Update::class.java)
            startActivity(intento6)
        }

        BTEliminar.setOnClickListener {
            val intento4 = Intent(this@MainActivity,Eliminar::class.java)
            startActivity(intento4)
        }

    }
}