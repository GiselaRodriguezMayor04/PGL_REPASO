package com.example.gisela_pgl_ut1

import android.annotation.SuppressLint
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class Update : AppCompatActivity() {
    private lateinit var ValorPremios: EditText
    private lateinit var ValorOyentes: EditText
    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_update)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }
        ValorPremios = findViewById(R.id.ETValorSubir)
        ValorOyentes = findViewById(R.id.ETValorNum)

        val BTConfirmar = findViewById<Button>(R.id.BTConfirmarAct)
        val BTVolver = findViewById<Button>(R.id.BTVolverAct)


        BTConfirmar.setOnClickListener {
            val radios = ConexionBD(this@Update, "BDGISELA", null, 1)
            val bd = radios.writableDatabase

            val regis = bd.rawQuery("Insert into Radios(numpremios) values(${ValorPremios.text.toString()}) where(numoyentes > ${ValorOyentes.text.toString().toInt()})",null)
            if(regis.moveToFirst()) {
                muestraMensaje("Valores actualizados correctamente")
            }else {
                muestraMensaje("El codigo del autor no se encuentra en la base de datos")
            }
            bd.close()
            limpiarCampos()
        }


        BTVolver.setOnClickListener {
            finish()
        }
    }

    private fun limpiarCampos() {
        ValorPremios.text.clear()
        ValorOyentes.text.clear()
    }

    private fun muestraMensaje(s: String) {
        Toast.makeText(this,s, Toast.LENGTH_LONG).show()
    }
}