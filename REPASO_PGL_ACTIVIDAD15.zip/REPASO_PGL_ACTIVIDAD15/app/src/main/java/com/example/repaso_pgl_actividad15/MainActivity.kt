package com.example.repaso_pgl_actividad15

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import kotlin.jvm.java

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        val ETNombre = findViewById<EditText>(R.id.ETNombre)
        val ETPassword = findViewById<EditText>(R.id.ETPassword)
        val BTEntrar = findViewById<Button>(R.id.BTEntrar)
        val BTSalir = findViewById<Button>(R.id.BTSalir)

        BTEntrar.setOnClickListener {
            val intento1 = Intent(this, Saludo::class.java)
            intento1.putExtra("nombre", ETNombre.text.toString())
            startActivity(intento1)
        }

        BTSalir.setOnClickListener {
            finish()
        }
    }

    override fun onStart() {
        super.onStart()
        Toast.makeText(this, "OnStart", Toast.LENGTH_LONG).show()
    }

    override fun onPause() {
        super.onPause()
        Toast.makeText(this, "onPause", Toast.LENGTH_LONG).show()
    }
}