package com.example.repaso_pgl_actividad14

import android.os.Bundle
import android.os.PersistableBundle
import android.widget.Spinner
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.example.repaso_pgl_actividad14.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val radiog1 = binding.RGRadio
        val tv = binding.TVTexto
        val cb = binding.CBCheck

        radiog1.setOnCheckedChangeListener { group, checkedId ->

            when (checkedId) {
                binding.RBPrimer.id -> {
                    tv.text = binding.RBPrimer.text
                }

                binding.RBSegun.id -> {
                    tv.text = binding.RBSegun.text
                }

                binding.RBTercer.id -> {
                    tv.text = binding.RBTercer.text
                }
            }
            cb.setOnCheckedChangeListener { buttonView, isChecked ->
                var mensaje =""
                if (isChecked) {
                    mensaje = "Abonado"
                } else  {
                    mensaje = "No Abonado"
                }
                Toast.makeText(this, mensaje, Toast.LENGTH_LONG).show()
            }
        }
        val SPSpinner = binding.spinner
        val TVResult = binding.TVResult

        val pro = ArrayAdapter.createFromResource(this, R.array.provincias, com.google.android.material.R.layout.support_simple_spinner_dropdown_item)

        SPSpinner.adapter = pro

        val islas = arrayOf("La Graciosa", "Lanzarote", "Fuerteventura", "Gran Canaria")
        val adap = ArrayAdapter(this, androidx.appcompat.R.layout.support_simple_spinner_dropdown_item, islas)
        SPSinner.adapter = adap

        SPSinner.onItemSelectedListener = object : AdapterView.onItemSelectedListener {
            override fun onItemSelected(
                parent: AdapterView<*>?,
                view: View?,
                position : Int,
                id: Long
            ) {
                TVResult.text = "Has seleccionado ${parent!!.getItemAtPosition(position)}"
            }

            override fun onNothingSelected(parent: AdapterView<*>?) {
                TVResult.text = "No has seleccionado nada"
            }
        }
    }
}